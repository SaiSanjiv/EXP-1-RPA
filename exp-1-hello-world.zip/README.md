# UiPath Exp-1: Hello World

This is a simple UiPath workflow that displays a **Hello World** message box.

## 📂 Files
- `Main.xaml` → The main workflow
- `project.json` → UiPath project definition

## ▶️ How to Run
1. Open UiPath Studio.
2. Clone or download this repo.
3. Open the folder in UiPath.
4. Run the project → You’ll see a "Hello World" message box.
